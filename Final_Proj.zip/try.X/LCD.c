/*
 * File:   LCD.c
 * Author: James
 * Description: Configure LCD
 * Created on May 5, 2023, 12:43 PM
 */


#include "xc.h"
#include "LCD.h"

void configure_LCD(void)
{
     // reset LCD panel to get it into a known state
    LCD_RESET = LOW;
    LCD_RESET = HIGH;
  
    
    LCDWrite(LCD_COMMAND, 0x21);  // LCD Extended Commands.
    LCDWrite(LCD_COMMAND, 0x80 );  // Set LCD Vop (Contrast), valid values of 0x80 - 0xFF, section 8.9 of data sheet. 
    LCDWrite(LCD_COMMAND, 0x04 );  // Set Temp coefficent, valid values are 0x04 - 0x07, typcally set to 0x04, section 8.7 and page 19 of data sheet
    LCDWrite(LCD_COMMAND, 0x13 );  // LCD bias mode, values values are 0x10 - 0x17, typically set to 0x13, 1:48, section 8.8 and Table 4 of data sheet
    LCDWrite(LCD_COMMAND, 0x20 );  // LCD Basic Commands
    LCDWrite(LCD_COMMAND, 0x0C );  // LCD in normal mode.
    
    
}