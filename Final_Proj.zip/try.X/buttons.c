/*
 * File:   buttons.c
 * Author: James
 * Description: Configure buttons
 * Created on May 5, 2023, 12:26 PM
 */


#include "xc.h"
#include "buttons.h"


void config_buttons()
{
    SWITCH1_PIN = IN;      //both switches set as inputs
    SWITCH2_PIN = IN;
}
