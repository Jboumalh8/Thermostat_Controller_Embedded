/*
 * File:   SPI.c
 * Author: James
 * Description: Configure SPI Communication protocol
 * Created on May 5, 2023, 12:52 PM
 */


#include "xc.h"
#include "SPI.h"

void configure_SPI(void)
{
    // setup SPI pins
    LCD_SCE_PIN = OUT;
    LCD_RESET_PIN = OUT;
    LCD_DC_PIN = OUT;

    // configure SPI1 for communication to LCD panel
    SPI1CON1bits.MSTEN = 1;    // make master
    SPI1CON1bits.PPRE = 0b11;  // 1:1 primary prescale
    SPI1CON1bits.SPRE = 0b111; // 1:1 secondary prescale
    SPI1CON1bits.MODE16 = 0;   // 8-bit transfer mode
    SPI1CON1bits.SMP = 0;      // sample in middle
    SPI1CON1bits.CKE = 1;      // Output on falling edge
    SPI1CON1bits.CKP = 0;      // CLK idle state low
    SPI1STATbits.SPIEN = 1;    // enable SPI1
    
       
}