#ifndef UI_H
#define	UI_H


#define OFF 0
#define ON  1

#define PROGRAMMING_LOW 0
#define PROGRAMMING_HIGH 1
#define INITIALIZING 2
#define RUNNING 3

#define NONE 0
#define HEATING 1
#define COOLING 2


#define UP_PRESSED 1
#define DOWN_PRESSED 2
#define BOTH_PRESSED 3




#define OFF 0
#define ON  1



// definitions for signaling on the D/C LCD line
#define LCD_COMMAND LOW
#define LCD_DATA    HIGH


void configure_LCD(void);
void LCDWrite(unsigned char, unsigned char);
void LCDCharacter(char);
void LCDclr(void);

void startConvertDS1631();
void startConvertDS1631(void);
void DS1631_readTemp();
void initINterrupts();
void configure_timer2();
void configPins();
void check_buttons();



void ui_LED();
void ui_LCD();
void ui_Log();
void LCDclr(void);
void configure_ui();
void ui(void);



 
#endif
