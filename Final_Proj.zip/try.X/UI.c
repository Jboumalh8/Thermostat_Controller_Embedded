/*
 * File:   UI.c
 * Author: James
 * Description: Update user interface
 * Created on May 5, 2023, 4:14 PM
 */


#include "xc.h"
#include <stdio.h>
#include <string.h>
#include "UI.h"
#include "I2C.h"
#include "SPI.h"
#include "RGB.h"
#include "UART.h"
#include "buttons.h"
#include "LCD.h"
#include "DS1631.h"
#include "fonts.h"


int I2C_ACK = 0;    // acknowledgment
int I2C_NACK = 1;   // no acknowledgment
double prev_temp;   //stores previous temperature
int double_press_count = 0;   //count for double press



int temp_hi;        // MSB Byte
int temp_lo;        // LSB Byte
double temp;         // stores 16-bit temp
double temperature;  // stores actual temperature
int button1;
int button2;


int buttons_state = NONE;   //stores button state


void LCD_string(char str[]);   //displays string on LCD
void LCD_putCursor(int x, int y);  //Places cursor on LCD
void LCD_number(double temperature);  //Displays number on LCD



int system_state = OFF;                   //Stores system state
int system_count = 0;                     //Stores system count
int old_system_state = OFF;               //Stores old system state
int programming_state = RUNNING;          //stores program state
int old_programming_state = INITIALIZING; //Stores previous program state
double old_temp = 72.0;                   //Stores old_temp for temp difference          
double low_temp = 73.0;                   //Stores low temp setting
double high_temp = 77.0;                  //Stores high temp setting
              


void configure_ui()
{
    //config timer 1
    T1CONbits.TON = 1;
    T1CONbits.TON = 0;
    T1CONbits.TCS = 0; 
    T1CONbits.TGATE = 0;
    TMR1 = 0;
    T1CONbits.TCKPS = 1;
    PR1 = 46061;
    IPC0bits.T1IP = 1; 
    IFS0bits.T1IF = 0; 
    IEC0bits.T1IE = 1;
    IFS0bits.T1IF = 0;
    T1CONbits.TON = 1;  
}

void __attribute__((__interrupt__, no_auto_psv))_T1Interrupt(void)  //whenever T1 expires, the user interface gets updated by calling the ui function
{
    
    ui();  //Call user interface function
    
    IFS0bits.T1IF = 0; // clear interrupt flag
    
}

void ui()
{
    DS1631_readTemp();    //read temperature from DS1631

    temp_hi = temp_hi << 8;
    temp = temp_hi | temp_lo; // combine MSB byte and LSB byte

    temperature = (temp / 32768.0) * 128.0 * 1.8 + 32;  //convert 16 bit temp to actual temp
    
    if (old_system_state == OFF)
    {
        if (system_count == 0)
        {
            printf("    System is now off\n\r");
            printf("    Low Temperature Setting = %.1f; High Temperature Setting = %.1f\n\r", low_temp, high_temp);
            system_count++;
        }
        if(temperature < low_temp - 0.5)
        {
            system_state = HEATING;      //System state is in cooling state
            printf("    Heating has turned on\n\r");
            old_system_state = system_state;
        }
        if(temperature > high_temp + 0.5)
        {
            system_state = COOLING;      //System state is in cooling state
            printf("    Cooling has turned on\n\r");
            
            old_system_state = system_state;  //Set old system state equal to current system state
            
        }
        
    }
        
     else if (old_system_state == HEATING)
        {
            if(temperature > low_temp + 0.5)
            {
                system_state = OFF;     //System state is in off state
                printf("    System is now off\n\r");
                
                old_system_state = system_state;   //Set old system state equal to current system state
            }
            if (temperature > high_temp)
            {
                system_state = COOLING;   //System state is in cooling state
                printf("    System is in running mode\n\r");
                printf("   Cooling has turned on\n\r");
                
                old_system_state = system_state;   //Set old system state equal to current system state
            }
           
        }
        else if (old_system_state == COOLING)
        {
            if(temperature < low_temp - 0.5 )   
            {
                system_state = HEATING;    //System state is in heating state
                printf("    System is in running mode\n\r");
                printf("    Heating has turned on\n\r");
                old_system_state = system_state;   //Set old system state equal to current system state
                
            }
            if (temperature < high_temp - 0.5)
            {
                system_state = OFF;    //System state is in off state
                printf("    System is now off\n\r");
                
                old_system_state = system_state;   //Set old system state equal to current system state
            }
            
        }
    
    
    
    if (buttons_state == NONE)
    {
        //Nothing happens
    }
    else if (buttons_state == UP_PRESSED)   //If up button pressed
    {
        if(programming_state == PROGRAMMING_LOW)
        {
            if (low_temp < high_temp){
        
            low_temp+=1;     // if programming state is programming low, then increment low_temp
    }
        }
            
        
        else if (programming_state == PROGRAMMING_HIGH )
        {
            
            high_temp +=1;   //if programming state is programming high, increment high_temp
            
        buttons_state = NONE;
    }
    }
    else if (buttons_state == DOWN_PRESSED)    //if down button is pressed
    {
        if (programming_state == PROGRAMMING_LOW)
        {
            
            low_temp-=1;    //if programming state is low then decrement temp
            
            
        }
        else if (programming_state == PROGRAMMING_HIGH)
        {
            
            if (high_temp > low_temp){
            high_temp-=1;            //if programming state is high, then decrement high_temp
            }
        
        buttons_state = NONE;
    }
         
    }
    
    else if (buttons_state == BOTH_PRESSED)  //If both butttons are pressed
    {
        if (programming_state == INITIALIZING || programming_state == RUNNING)
        {
            printf("    System is programming Low Temperature\n\r");
            programming_state = PROGRAMMING_LOW;     //set programming state as low
            old_programming_state = RUNNING;         //store old programming state
        }
        else if (programming_state == PROGRAMMING_LOW)   //if programming state is low
        {
            printf("    System is programming High Temperature\n\r");
            programming_state = PROGRAMMING_HIGH;        //set programming_state as high
            old_programming_state = PROGRAMMING_LOW;     //store old programming state
        }
        else if (programming_state == PROGRAMMING_HIGH)  //if programming state is high
        {
            programming_state = RUNNING;      //Set programming state as running
            old_programming_state = PROGRAMMING_HIGH;    //store old programming state
            
            printf("    Low Temperature Setting = %.1f; High Temperature Setting = %.1f\n\r", low_temp, high_temp);
            
        }
        else 
        {
            programming_state = RUNNING;
            old_programming_state = INITIALIZING;
            
            
            
        }
          
        
        buttons_state = NONE;
    }
        
      
  ui_LED();  //update LED
  ui_LCD();  //Update LCD
  ui_Log();  //Update 
  
  old_temp = temperature;  //store current temp in old temp
}


void ui_LED()
{
    if(system_state == OFF)  //if system state is off
    {
        GREEN_LED = ON;    //turn on green led
        RED_LED = OFF;
        BLUE_LED = OFF;
    }
    else if(system_state == HEATING)   //if system state is heating 
    {
        GREEN_LED = OFF;
        RED_LED = ON;    //red led on
        BLUE_LED = OFF;
    }
    else if (system_state == COOLING)   //if system state is cooling
    {
        GREEN_LED = OFF;
        RED_LED = OFF;
        BLUE_LED = ON;        //blue led on
    }
}

void ui_LCD()
{
    if(programming_state == PROGRAMMING_LOW)  //if programming state low
    {
        
            LCDclr();
            LCD_string("Temp:  ");
            LCD_putCursor(0x80  , 0x40 | 3);     //Display strings on LCD
            LCD_string("Low Temp  ");
            LCD_putCursor(0x80, 0x40 | 0x4);
            LCD_string("Set:  ");
        
        LCD_putCursor(0x80 | 40, 0x40);
        LCD_number(temperature);          //Display temperature on LCD
        
        LCD_putCursor(0x80 | 40,0x40 | 0x4);
        LCD_number(low_temp);             //Display  low temp on LCD
        
        
    }
    else if(programming_state == PROGRAMMING_HIGH)  //IF programming state is high
    {
        
            LCDclr();
            LCD_string("Temp:  ");
            LCD_putCursor(0x80,0x40 | 3);     //Display strings on LCD
            LCD_string("High Temp ");
            LCD_putCursor(0x80,0x40 | 0x4);
            LCD_string("Set: ");
        
        LCD_putCursor(0x80 | 40, 0x40);
        LCD_number(temperature);            //Display temp
       
        LCD_putCursor(0x80 | 40,0x40 | 0x4);
        LCD_number(high_temp);             //Display high_temp
       
        
    }
    else
    { 
        if (programming_state != old_programming_state)  //if programming state is diff from old programming state
        {
            LCDclr();
            LCD_string("Temp: ");      //display string temp
        }
        LCD_putCursor(0x80 | 40, 0x40);
        LCD_number(temperature);      //display temperature
        if(system_state != old_system_state || programming_state != old_programming_state)
        {
            LCD_putCursor(0x80,0x40 | 0x3);
            if(system_state == OFF)
            {
                LCD_string("System Off ");  //if system state is off display it  
                
            }
            else if (system_state == HEATING)
            {
                LCD_string("Heat ON  ");   //if heat system is on display it
            }
            
            else if (system_state == COOLING)
            {
                LCD_string("Cooling On");   //if cooling system is on dispplay it
                
                
            }
        }
    }
    
}


void ui_Log()
{
    
    double temp_dif = 0;
    
    temp_dif = temperature - old_temp;  //stores temp difference
    
    if( temp_dif > 0.5)
    {
        printf("    The temperature increased by %.2f to %.2f\n\r", temp_dif, temperature);
    }
    else if (fabs(temp_dif) > 0.5)
    {
        printf("    The temperature decreased by %.2f to %.2f\n\r", fabs(temp_dif), temperature);
    }
    
    
}

void LCD_string(char str[])
{
       for (int i = 0; i < strlen(str); i++) {   //display characters on LCD
     
            LCDCharacter(str[i]);
       }

    
}

void LCD_putCursor(int x, int y)
{
    LCDWrite(LCD_COMMAND,x);   //Put cursor on LCD
    LCDWrite(LCD_COMMAND,y);
}


void LCD_number(double temperature)
{
    char str[10];
    sprintf(str, "%.1f", temperature); // convert float to string with one decimal place
     
    for (int i = 0; i < strlen(str); i++) {
     
    LCDCharacter(str[i]);   //Display tmeperature on lcd

}
}

void LCDclr(void)
{
    int i;
    for (i=0;i<6*84;i++){
        LCDWrite(LCD_DATA,0x00);    //Clear LCD
    }
    LCDWrite(LCD_COMMAND,0x40);
    LCDWrite(LCD_COMMAND,0x80);    //Set cursor top left
}

// writes one byte of data to the LCD panel
void LCDWrite(LCDBYTE dc, LCDBYTE data) {
    LCD_SCE = LOW;    // Selection LCD panel
    LCD_DC = dc;      // Indicate Data/Command signal
    SPI1BUF = data;   // Put data in output buffer for SPI1
    while(!SPI1STATbits.SPIRBF){} // wait for it to send
    Nop();            // A little extra wait time
    LCD_SCE = HIGH;   // Deselect LCD panel
       
}

// Draws one 8x5 character using the font table on LCD panel with a blank column before and after character
void LCDCharacter(char character)
{
    int index;
    LCDWrite(LCD_DATA, 0x00);
    for (index = 0; index < 5; index++) {
        LCDWrite(LCD_DATA, ASCII[character - 0x20][index]);
    }
    LCDWrite(LCD_DATA, 0x00);
}

void DS1631_readTemp()
{
    startI2C2(); // Start transfer
    putI2C2(0b10010000 & 0xFE); // Send address, lsb 0
    putI2C2(0xAA); // Send read temp cmd
    rstartI2C2(); // restart transfer
    putI2C2(0b10010000 | 0x01); // Send address, lsb 1
    temp_hi = getI2C2(I2C_ACK); // get MSB of temp
    temp_lo = getI2C2(I2C_NACK);// get LSB of temp
    stopI2C2(); // Stop transfer
   
}

void initINterrupts(){
    
    INTCON2bits.GIE = 1;   //CHANGE INTERRUPT ENABLE
    IFS1bits.CNIF = 0;     // Clears the change notification interrupt flag
    IPC4bits.CNIP = 4;     //set priority to 4
    IEC1bits.CNIE = 1;     // Enables the change notification interrupt 
}

void configure_timer2()
{
    INTCON2bits.GIE = 1;          // Enable interrupts
    T2CONbits.TON = 0;            // Turn Timer2 off
    T2CONbits.TCS = 0;            // Use internal clock source
    T2CONbits.TGATE = 0;          // Disable gated timer mode
    TMR2 = 0;                     // Reset Timer2
    T2CONbits.TCKPS = 0;          // Set prescaler to 1:1
    
    
    PR2 =  36000;
     
    IFS0bits.T2IF = 0;            // Clear Timer2 interrupt flag
    IPC1bits.T2IP = 3;            // Set interrupt priority to 3
    IEC0bits.T2IE = 1;            // Enable Timer2 interrupt
    
    
}

void __attribute__((interrupt, no_auto_psv)) _T2Interrupt(void) //When timer 2 expires the Timer 2 routine executes which stores which buttons were pressed
{
    IFS1bits.CNIF = 0;     // Clear interrupt flag
    T2CONbits.TON = 0;     // Turn off Timer2
    
    check_buttons();       //The check_buttons function is called to store the button state based on which buttons pressed
        
    
    IEC1bits.CNIE = 1;     // Enable change notification interrupt 
    IFS0bits.T2IF = 0;     // clear interrupt flag
}

           
void __attribute__((__interrupt__,no_auto_psv)) _CNInterrupt()  //Change notification interrupt called when either button is pressed
{
 
    IEC1bits.CNIE = 0;    //DISABLE CN INTERRUPT
    
    T2CONbits.TON = 1;            // Turn on Timer2 to store which buttons pressed
     
    IFS1bits.CNIF = 0; // Clear interrupt flag
    
    
}

void configPins()
{
    CNENAbits.CNIEA2 = 1;   //Enable change notificiation for RA2
    CNPUAbits.CNPUA2 = 1;   //CHANGE INTERRUPT SET UP PINS
    CNENBbits.CNIEB4 = 1;   //Enables change notification interrupt for pin RB4
    CNPUBbits.CNPUB4 = 1;   //Enables pull-up resistor for pin RB4

}

void check_buttons()
{
    //Check which buttons are pressed and buttons state is updated
    button1 = SWITCH1;
    button2 = SWITCH2;
    
    if(button1 == ON && button2 == ON)
    {
        buttons_state = NONE;   
    }
    else if (button1 == OFF && button2 == ON)
    {
        buttons_state = UP_PRESSED;
    }
    else if (button1 == ON && button2 == OFF)
    {
        buttons_state = DOWN_PRESSED;
    }
    else if (button1 == OFF && button2 == OFF)
    {
        buttons_state = BOTH_PRESSED;
    }
}

void startConvertDS1631(void)
{
    startI2C2();   //initiate communication
    putI2C2(0b10010000 & 0xFE);  //send address
    putI2C2(0x51);  //start convert T command 
    stopI2C2();    //end communication
}

