#ifndef RGB_H
#define	RGB_H

#define BLUE_LED_PIN    TRISAbits.TRISA0     /* Blue LED pin */
#define BLUE_LED        LATAbits.LATA0
#define GREEN_LED_PIN   TRISAbits.TRISA1     /* Green LED pin */
#define GREEN_LED       LATAbits.LATA1
#define RED_LED_PIN     TRISBbits.TRISB1     /* Red LED pin */
#define RED_LED         LATBbits.LATB1

// definitions for pin input and output
#define IN  1
#define OUT 0
 
void configure_rgbLED();
 

#endif