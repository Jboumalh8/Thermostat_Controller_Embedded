/*
 * File:   man.c
 * Author: James Boumalhab
 * Description: Put together a complete embedded system. The system will be a
   thermostat controller with an output display.
 * Created on May 5, 2023, 2:21 PM
 */


#include "xc.h"
#include "config.h"
#include "fonts.h"
#include <stdio.h>
#include <string.h>
#include "UI.h"
#include "I2C.h"
#include "SPI.h"
#include "RGB.h"
#include "UART.h"
#include "buttons.h"
#include "LCD.h"
#include "DS1631.h"



// Pins for SPIx
#define USE_SPI1


int main(void) {
    
    config_UART();
    
    printf("\033[2J\033[;H");   // clear screen
    printf("BEGINNING OF LOG\r\n\n"); 
    printf("Initializing System\r\n");
    
    printf("     Configuring Hardware\r\n");
    
    configure_SPI();  //Function to configure SPI
    configure_LCD();  //Fucntion to configure LCD
    LCDclr();         //Function to clear LCD
    
    // Config system
    config_I2C();         //Function to configure I2C
    config_DS1631();      //Function to configure DS1631
    config_buttons();     //Function to configure buttons
    configure_rgbLED();   //Function to configure rgb_LED
    configPins();         //Function to configure pins
    initINterrupts();     //Function to configure CN interrup
    configure_timer2();   //configure timer 2 function
    
   
   
    
    printf("     Start Measuring Temperature\r\n");
    startConvertDS1631();    //Begin with DS1631 sensor conversion
    
    printf("     Start the UI\r\n\n");
    
    configure_ui();     //Function to configure user interface
    
    printf("System up and Running\r\n");
    
   
    
     while (1) {
        
         Idle();   //Processor idles
    }
    
    return 0;
}






