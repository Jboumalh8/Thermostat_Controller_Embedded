#ifndef UART_H
#define	UART_H

#define BAUDRATE 19200
#define FCY 7370000/2

 void config_UART(void);


 

#endif