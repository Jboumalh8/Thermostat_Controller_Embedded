#ifndef I2C_H
#define	I2C_H

#include <stdio.h>
#define BAUDRATE 19200
#define FCY 7370000/2
#define FSCL 100 // Clock frequency in kHz


void config_I2C(void);
void startI2C2(void);
int putI2C2(int data);
void stopI2C2(void);
int getI2C2(int ack2send);
void rstartI2C2(void);
 
 
 

#endif