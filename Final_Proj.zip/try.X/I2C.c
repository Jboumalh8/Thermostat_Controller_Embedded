/*
 * File:   I2C.c
 * Author: James
 * Description: Configure I2C
 * Created on May 5, 2023, 1:43 PM
 */

#include "I2C.h"
#include "xc.h"

void config_I2C(void)
{
     I2C2BRG = 0x1F;   //BAUD RATE GENETATOR
    I2C2CONbits.I2CEN = 1;  //enable I2C
    
}

void startI2C2(void) {

   I2C2CONbits.SEN = 1; // initialize start

   while(I2C2CONbits.SEN); // wait until start finished
}

 int putI2C2(int data) {

   I2C2TRN = data; // put data in transmit buffer
   while(I2C2STATbits.TRSTAT); // wait until transfer finished

return(I2C2STATbits.ACKSTAT); // return ACK signal
}

void stopI2C2(void) {

   I2C2CONbits.PEN=1; // initiate stop, PEN=1
   while(I2C2CONbits.PEN); // wait until stop finished
}


int getI2C2(int ack2send) {
  
    unsigned char inByte;

    while(I2C2CON & 0x1F); // wait for idle condition
    I2C2CONbits.RCEN=1; // enable receive
    while(!I2C2STATbits.RBF); // wait for receive byte
    inByte = I2C2RCV; // read byte

    while(I2C2CON & 0x1F); // wait for idle
    I2C2CONbits.ACKDT = ack2send; // ACK type to send
    I2C2CONbits.ACKEN = 1; // enable ACK bit transmission
    while(I2C2CONbits.ACKEN); // wait until done

return(inByte);
}


void rstartI2C2(void)
{
    I2C2CONbits.RSEN = 1;
    while(I2C2CONbits.RSEN); // wait until start finished

}