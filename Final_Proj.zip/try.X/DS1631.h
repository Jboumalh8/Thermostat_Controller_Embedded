#ifndef DS1631_H
#define	DS1631_H


void config_DS1631();
 
#endif