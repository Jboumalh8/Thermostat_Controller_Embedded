#ifndef buttons_H
#define	buttons_H

#define SWITCH1_PIN     TRISAbits.TRISA2     // Switch1
#define SWITCH1         PORTAbits.RA2
#define SWITCH2_PIN     TRISBbits.TRISB4     // Switch2
#define SWITCH2         PORTBbits.RB4
#define IN  1
#define OUT 0

void config_buttons();

 
 
 

#endif