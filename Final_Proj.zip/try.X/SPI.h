#ifndef SPI_H
#define	SPI_H

// Pins for LCD Control Signals
#define LCD_SCE         LATBbits.LATB12     /* SPI Chip Enable pin RB12 */
#define LCD_SCE_PIN     TRISBbits.TRISB12
#define LCD_RESET       LATBbits.LATB13     /* LCD Reset pin RB13 */
#define LCD_RESET_PIN   TRISBbits.TRISB13
#define LCD_DC          LATBbits.LATB14     /* LCD Data/Command pin RB14 */
#define LCD_DC_PIN      TRISBbits.TRISB14

// definitions for pin input and output
#define IN  1
#define OUT 0

 void configure_SPI(void);
 
 

#endif