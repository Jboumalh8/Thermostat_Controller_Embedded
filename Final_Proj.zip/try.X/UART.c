/*
 * File:   UART.c
 * Author: James
 * Description: Configure UART protocol
 * Created on May 5, 2023, 12:29 PM
 */


#include "xc.h"
#include "UART.h"

void config_UART(void) {
    RPINR18bits.U1RXR = 42;     // map UART1 RX to pin RP42
    RPOR4bits.RP43R = 1;     //MAP UART1 TX to pin RP43
    
    int brg = (FCY/BAUDRATE/4)-1;  //baud rate generator value
    U1MODEbits.BRGH = 1;   //high speed mode
    U1BRG = brg;   //store value in register 
    
    U1MODEbits.PDSEL = 0;   //8 bit data, no parity 
    U1MODEbits.STSEL = 0;   //1 stop bit
    
    
    U1MODEbits.UEN = 0b00;  //RX and TX pins are enabled
    U1MODEbits.UARTEN = 1;  //enable UART RX and TX 
    U1STAbits.UTXEN = 1;    //Enable transmitter
}


void putch(float n)
{
    while(U1STAbits.UTXBF);  //check if transmit buffer is empty
    U1TXREG = n; //if empty write number to transmit register
    
}