/*
 * File:   DS1631.c
 * Author: James
 * Description: Configure DS1631 temperature sensor
 * Created on May 5, 2023, 12:49 PM
 */


#include "xc.h"
#include "DS1631.h"

void config_DS1631()
{
    startI2C2();  //initiate communication
    putI2C2(0b10010000 & 0xFE); // Send address, lsb 0
    putI2C2(0xAC); // Send access config command
    putI2C2(0x0C); //Configuration data (set temperature conversion resolution to 12 bit mode)
    stopI2C2();    //end communication
}
