#ifndef LCD_H
#define	LCD_H


// definitions for signaling on the D/C LCD line
#define LCD_COMMAND LOW
#define LCD_DATA    HIGH
#define LCD_RESET       LATBbits.LATB13     /* LCD Reset pin RB13 */
#define LCD_RESET_PIN   TRISBbits.TRISB13
// definitons for signaling high and low
#define LOW  0
#define HIGH 1


void configure_LCD(void);

 
#endif