/*
 * File:   RGB.c
 * Author: James
 * Description: Configure RGB LED
 * Created on May 5, 2023, 12:24 PM
 */


#include "xc.h"
#include "RGB.h"

void configure_rgbLED() {
       
    /* Configure RA0, RA1, and RB0 as output pins for LED */
    RED_LED_PIN = OUT;    
    GREEN_LED_PIN = OUT; 
    BLUE_LED_PIN = OUT; 
    
 }